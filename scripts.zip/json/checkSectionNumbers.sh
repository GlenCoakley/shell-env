#!/bin/sh

showCorrect=0
jqSpec='.document.test, .sessions[0].level, .demographics.districtCode, .demographics.schoolCode, .bubbleData.scannedAt'
echo "File path, $jqSpec, scan time, pages"

function toCSV() {
	echo $@ | tr -s ' ' ','
}

function toTabDelim() {
	echo $@ | tr -s ' ' '	'
}

declare -i correctScanCount=0
# echo temp_glen/scoringPayload.sort.json | 
# echo temp_glen/553d0637-7e88-4b7b-9f4c-aeada678f13d/documentResults/1119904-20338703/scoringPayload.sort.json |
find temp_glen -type f -name 'scoringPayload*.json' |
	while read scoreFile; do
	names=$(jq "$jqSpec" < $scoreFile | xargs echo)
	sections=$(grep testSessionNumber < $scoreFile | sort|uniq | head | cut -d: -f2 | sort)
	sectionCount=$(echo $sections | wc -w)
	sectionArray=$(echo $sections | tr -d '[:space:]')
	firstName=$(echo $names | cut -d' ' -f1)	
#	echo "Checking $scoreFile  $names  $sectionCount"
	
	if [ "$(echo $firstName | cut -c1-3)" == "LOC" ]; then
		if [ $showCorrect -eq 0 ] && [ $sectionArray == "1,2,3,4," ]; then
			correctScanCount= # $(echo "$correctScanCount +1" | bc)
		else
			toCSV "$scoreFile $names \"$sectionArray\""
		fi
	elif [ "$(echo $firstName | cut -c1-4)" == "TABE" ]; then
		if [ $showCorrect -eq 0 ] && [ $sectionArray == "1,2,3,4,5,6,7,8," ]; then
			correctScanCount= # $(echo "$correctScanCount +1" | bc)
		else
			toCSV "$scoreFile $names \"$sectionArray\""
		fi
	else
		toCSV "$scoreFile $names \"$sectionArray\""
	fi
done
#echo "$correctScanCount scans look correct."