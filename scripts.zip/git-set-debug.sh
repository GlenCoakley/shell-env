
value=1

case "$1" in 
   [oO][nN])		value=1 ;;
   [tT][rR][uU][eE]) 	value=1 ;;

   [oO][fF][fF])	value=0 ;;
   [fF][aA][lL][sS][eE]) value=0 ;;
esac

export GIT_TRACE=$value
export GCM_TRACE=$value

