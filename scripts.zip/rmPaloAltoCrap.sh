#!/bin/bash

export PATH=/c/dev/bin/cygwin64/bin:/c/home/gcoakley/scripts:$PATH

gfind $TMP /c/tmp /c/Windows/Temp /c/Users -name '^\!\!\!\!\!*\|^ZZZZZ*\|^XORXOR*' -print0 | xargs -0 rm -rf 

