#!/bin/sh

# Spawns serverless in the background waiting for

# We tried using packages such as npm-run-all, npm-run-parallel but they started the jobs immediatly which didn't allow
# enough time to copy the appropriate serverless config file to serverless.yml and load it into memory before the next
# instance was started with a new config. file. So, the multiple instances ran with the same configuration.

if [ "$#" -eq 0 ]; then
  echo "Usage: '{serverless command with args}' ... "
  echo "  You can pass multiple commands."
  echo "  If your command needs arguments enclose the whole command and arguments in "
  echo "  single quotes."
  echo "  Ex: $(basename $0) 'npm run something' 'serverless offline start' "
  exit 1
fi

for arg in "$@"; do
  echo "Starting in the background: $arg"
  log=$(echo $arg| tr -c '[:alnum:]' '_').log
  echo nohup $arg > $log &

  while true; do
    listeningCount=$(grep -c '^Serverless:.*listening on' $log)
    if [ "$listeningCount" -ge 1 ]; then
      break;
    fi
    exceptionCount=$(grep -c '^java\.[^ ]*Exception: ' $log)
    if [ "$exceptionCount" -ge 1 ]; then
      echo ''
	  echo 'Exception during startup: '
      grep '^java\.[^ ]*Exception: ' $log
	  echo ''
      exit 2
    fi
    echo 'still waiting...'
    sleep 5
  done
done

