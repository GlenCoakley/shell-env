#!/bin/env bash

DEST_FILE=.gitignore
URL_GH=https://github.com/github/gitignore/blob/master
URL_GI=https://www.gitignore.io/api

# Currently unused: NotepadPP VisualStudio
for sw in Node Gradle Grails
do wget $URL_GH/${sw}.gitignore -O - >> $DEST_FILE; done

# Currently unused: Windows
decare -a globalArr=(Backup Vim VisualStudioCode Xcode)
for sw in ${globalArr[*]}
do wget $URL_GH/Global/{$sw}.gitignore -O - >> $DEST_FILE; done

# Currently unused: microsoftoffice notepadpp windows
for sw in angular bower coffeescript emacs intellij jetbrains kdiff3 linux macos serverless xcode yeoman
do
   wget $URL_GI/api/$sw			-O - >> $DEST_FILE
done
