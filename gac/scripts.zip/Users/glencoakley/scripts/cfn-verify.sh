#!/bin/sh

stack=$(jq -r '.service.service' .serverless/serverless-state.json)
region=$(jq -r '.service.provider.region' < .serverless/serverless-state.json | uniq)
stage=$(jq -r '.service.provider.stage' < .serverless/serverless-state.json | uniq)

echo ''
echo 'CloudFormation linting issues:'
echo '  This currently ignores warnings because DependsOn, which we use a lot, is deprecated.'
echo ''
cfn-lint -r 'us-east-1,us-east-2' --template .serverless/cloudformation-template-update-stack.json --ignore-checks W $@
echo "cfn-lint returned $?"

echo ''
echo 'CloudFormation maintainability or security issues:'
echo ''
if [ $(test -t 0) ]; then
  ARG_IF_NOT_TTY=''
else
  ARG_IF_NOT_TTY='--output-format=txt'
fi
cfn_nag_scan --input-path .serverless/cloudformation-template-update-stack.json $ARG_IF_NOT_TTY $@
echo "cfn_nag_scan returned $?"

echo ''
echo "Validated CloudFormation template for stack: '${stack}', stage: '${stage}', and region: '${region}'."
echo '  To validate a different configuration run one of the following then rerun this script: '
echo '  serverless package -c <serverless-yaml-file> --stage <stage> --region <region>'
echo '      or'
echo '  sls package -c <serverless-yaml-file> -s <stage> -r <region>'
echo 'If you have not installed these tools then run: cfn-verify-install.sh.'

