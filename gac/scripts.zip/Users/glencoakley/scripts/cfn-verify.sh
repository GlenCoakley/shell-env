#!/bin/sh

stack=$(jq -r '.service.service' .serverless/serverless-state.json)
region=$(jq -r '.service.provider.region' < .serverless/serverless-state.json | uniq)
stage=$(jq -r '.service.provider.stage' < .serverless/serverless-state.json | uniq)

echo ''
echo 'CloudFormation linting issues:'
echo ''
cfn-lint -r 'us-east-1,us-east-2' --template .serverless/cloudformation-template-update-stack.json $@
echo "cfn-lint returned $?"

echo ''
echo 'CloudFormation maintainability or security issues:'
echo ''
cfn_nag_scan --input-path .serverless/cloudformation-template-update-stack.json $@
echo "cfn_nag_scan returned $?"

echo ''
echo "Validated CloudFormation template for stack: '${stack}', stage: '${stage}', and region: '${region}'."
echo '  To validate a different configuration run one of the following then rerun this script: '
echo '  serverless package -c <serverless-yaml-file> --stage <stage> --region <region>'
echo '      or'
echo '  sls package -c <serverless-yaml-file> -s <stage> -r <region>'
echo 'If you have not installed these tools then run: cfn-verify-install.sh.'

