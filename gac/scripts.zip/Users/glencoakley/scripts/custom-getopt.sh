# from: https://stackoverflow.com/questions/16483119/an-example-of-how-to-use-getopts-in-bash
# Example:
#   Usage: "./script.sh package install --package "name with space" --build --archive"
# parseArguments "${@}"
# echo "${ARG_0}" -> package
# echo "${ARG_1}" -> install
# echo "${OPT_PACKAGE}" -> "name with space"
# echo "${OPT_BUILD}" -> 1 (true)
# echo "${OPT_ARCHIVE}" -> 1 (true)
#
function parseArguments() {
  PREVIOUS_ITEM=''
  COUNT=0
  for CURRENT_ITEM in "${@}"
  do
    if [[ ${CURRENT_ITEM} == "--"* ]]; then
      # Handle flag options (that had no arguments).
      # Could set this to empty string and check with [ -z "${ARG_ITEM-x}" ].
      # If it's set, but empty.
      printf -v "OPT_$(formatArgument "${CURRENT_ITEM}")" "%s" "1" 
    else
      # Handle options with arguments.
      if [[ $PREVIOUS_ITEM == "--"* ]]; then
        printf -v "OPT_$(formatArgument "${PREVIOUS_ITEM}")" "%s" "${CURRENT_ITEM}"
      else
        # Handle arguments (not options).
        printf -v "ARG_${COUNT}" "%s" "${CURRENT_ITEM}"
      fi
    fi

    PREVIOUS_ITEM="${CURRENT_ITEM}"
    (( COUNT++ ))
  done
}

# Format argument.
function formatArgument() {
  local ARGUMENT
  ARGUMENT="${1^^}" # Capitalize.
  ARGUMENT="${ARGUMENT/--/}" # Remove "--".
  ARGUMENT="${ARGUMENT//-/_}" # Replace "-" with "_".
  echo "${ARGUMENT}"
}

parseArguments
env | grep '^ARG_\|^OPT_' | sort

