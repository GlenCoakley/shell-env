#!/usr/bin/env bash

URL=${1:-http://localhost}
if [ $(curl -sSLI $URL | grep -c '^HTTP/') -gt 0 ]; then 
   echo yes
else
   echo no
fi

