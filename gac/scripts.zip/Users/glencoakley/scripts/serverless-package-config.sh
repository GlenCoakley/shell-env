#!/bin/sh

STAGE=$1
DEPLOY_TYPE=$2
if [ -z "$DEPLOY_TYPE" ]; then
  echo "Usage: <stage-env.> <data|lambda>"
  exit 1
fi

rm -rf .serverless && ./scripts/jenkins/serverlessYmlCopy.sh $DEPLOY_TYPE
npx sls package --stage $STAGE

cd .serverless/ && (unzip -o *.zip ; ls -l) && cd ..

mkdir -p .serverless.$DEPLOY_TYPE.new.$STAGE
cp -rp .serverless/* .serverless.$DEPLOY_TYPE.$STAGE/

