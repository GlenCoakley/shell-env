sed -e 's/export //' -e 's/"//g' -e 's/$/;/' ~/.aws/credentials.env | tr -d '\r\n'

