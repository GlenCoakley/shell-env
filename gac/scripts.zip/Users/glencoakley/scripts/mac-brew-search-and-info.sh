#!/usr/bin/env bash

if [ -z "$1" ]; then
   echo 'Usage bsi: <package name substring>'
   exit 1
fi

TMPFILE=$(mktemp); trap "rm -f $TMPFILE" 0 1 2 3 9 15;
brew search $@ > $TMPFILE
cat $TMPFILE
echo -e '\nPackage Information:'
cask=''
cat $TMPFILE | grep -v '^==>' | while read pkg; do
   if [ -z "$pkg" ]; then cask=cask; continue; fi
   brew $cask info $pkg 2>/dev/null | head -3 | grep -v '^Not installed'
   echo ''
done

