#!/bin/bash

find src spec db scripts -name '*.ts' | while read tsFile; do
  dirname=$(dirname $tsFile)
  jsFile=$(echo $tsFile | sed -e 's/.ts$/.js/')
  rm -vf ${jsFile} ${jsFile}.map
done
