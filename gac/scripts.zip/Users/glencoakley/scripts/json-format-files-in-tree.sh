#!/bin/sh

COLS=$(tput cols)

find . -name '*.json' | grep -v '.fmtd.json' | while read file; do
   fmtd=$(echo $file | sed -e 's;.json;.fmtd.json;g')
   printf "%-${COLS}s\r" "$fmtd"
   jq '.' < $file > $fmtd
done

