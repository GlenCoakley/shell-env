npm audit | grep '^# Run '
