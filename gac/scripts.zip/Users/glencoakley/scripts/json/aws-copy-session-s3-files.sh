#!/bin/sh

# TABE/data/4a025bbc-a841-456d-b4df-2ebaa45e30f3/documentResults/1119902-80258726/scoringPayload.json

for arg in $@; do
    if [ $(echo "$arg" | grep -c ^TABE) -eq 1 ]; then 
        sessId=$(echo $arg | cut -d/ -f3)
        scanid=$(echo $arg | cut -d/ -f5)
		if [ ! -d "$sessId/$scanId/" ]; then
	        mkdir -p $sessId/$scanId/
			aws s3 cp s3://form-recognition-images-prod/$a $sessId/$scanId/
		else
			echo "$sessId/$scanId/ already exists."
		fi
    else
        sessId=$arg
		if [ ! -d "$sessId/$scanId/" ]; then
			mkdir -p $sessId
			aws s3 cp --recursive --quiet s3://form-recognition-images-prod/TABE/data/$sessId/ $sessId/
			count=$(find $sessId -type f | wc -l)
			echo "$count files copied to $sessId/"
		else
			echo "$sessId/$scanId/ already exists."
		fi
    fi
done

if [ -z "$1" ]; then
    echo ''
    echo "Usage: $(basename $0)"
    echo ''
    echo "You must assume a DRC production role."
    exit 1
fi
