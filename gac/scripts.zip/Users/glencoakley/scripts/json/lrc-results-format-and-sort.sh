#!/bin/sh

TMPDIR=temp_glen
#rm -rf $TMPDIR/*

find . -type f -name scoring\*.json | grep -v 'temp_glen' | while read input; do 
	formatted=$(echo $input | sed -e 's/.json$/.fmtd.json/')
	sorted=$(echo $input | sed -e 's/.json$/.sort.json/')
	dirname=$(dirname $input)
	mkdir -p $TMPDIR/$dirname

	if [ "$(echo $formatted | grep -c '\..*\.json$')" -eq 0 ]; then 
		echo "Script error. Formatted file name is incorrect: $formatted."
		continue
	elif [ "$(echo $sorted | grep -c '\..*\.json$')" -eq 0 ]; then 
		echo "Script error. Sortted file name is incorrect: $sorted."
		continue
		# .demographics.extensions |= sort_by(.name) //
	else
		echo "  Reading: $input"
		jq '' < $input > $TMPDIR/$formatted

		if [ "$(echo $input | grep -c demographicResults)" -eq 1 ]; then
 			jq '
 				. |= sort_by(.testSessionNumber) // 
				.
 				' < $TMPDIR/$formatted > $TMPDIR/$sorted
		fi
		if [ "$(echo $input | grep -c inputResults)" -eq 1 ]; then
 			jq '
 				. |= sort_by(.itemId) //
 				. |= group_by(.testSessionNumber) //
				.
 				' < $TMPDIR/$formatted > $TMPDIR/$sorted
		fi
		if [ "$(echo $input | grep -c scoringPayload)" -eq 1 ]; then
			jq '
				.sessions[].items |= sort_by(.itemId) | 
				.sessions |= sort_by(.form) //
				.bubbleData.demographicResults |= sort_by(.humanReadableId) // 
				.inputResults |= sort_by(.testSessionNumber) //
				.
				' < $TMPDIR/$formatted > $TMPDIR/$sorted
		fi
		
		if [ -r "$TMPDIR/$sorted" ] && [ "$(stat -f '%z' $TMPDIR/$sorted)" -eq "$(stat -f '%z' $TMPDIR/$formatted)" ]; then
			rm $TMPDIR/$formatted
		fi
	fi
done

# find $TMPDIR -type f -ls | tr -s ' ' | cut -d' ' -f7- | while read size other; do
# 	printf "%9d %s\n" $size "$other"
# done
echo "Processed files are in $TMPDIR/"
