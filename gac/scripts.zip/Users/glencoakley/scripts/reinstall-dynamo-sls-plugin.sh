#!/bin/sh
# If you manually remove either of the 'node_modules' or '.dyunamodb' subdirectories it will prevent the local
# 'serverless' command from running properly. This will fix it and possibly other causes of the error:
#    Cannot load dynamodb.

# Whatever occasionally nukes this plugin does not do it cleanly. So, uninstall all remnants.
sls plugin uninstall --name serverless-dynamodb-local --stage dev --region us-east-2

# Install the plugin into serverless (sls).
sls plugin install --name serverless-dynamodb-local --stage dev --region us-east-2
sls dynamodb install --stage dev --region us-east-2
