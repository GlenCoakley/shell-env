brew install jq
brew install python3
pip3 install cfn-lint
brew install ruby brew-gem
brew gem install cfn-nag

