# For cfn-lint
brew install jq
brew install python3
pip3 install cfn-lint

# For cfn-nag
brew install ruby brew-gem
brew gem install cfn-nag

echo "cfn-lint bundles its own copy of the resource specification, so if you’re not on the latest version, it won’t recognize legitimate new resources or properties. They’re also frequently adding new rules which will help you improve your templates."
echo ''
echo "To update run: pip3 install --upgrade cfn-lint"
echo ''
