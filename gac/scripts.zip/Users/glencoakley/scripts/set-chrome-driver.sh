#!/bin/sh

chromeExec=$(find-chrome.sh)
# Expecting a --version output like: Google Chrome 80.0.3987.149
chromeVersion=$("$chromeExec" --version | cut -d ' ' -f 3)

npm install --save-dev webdriver-manager
node_modules/.bin/webdriver-manager update --versions.chrome=$chromeVersion
