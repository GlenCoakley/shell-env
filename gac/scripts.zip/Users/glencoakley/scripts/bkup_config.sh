#!/bin/env sh

find . -type f -name '\.*' -maxdepth 1 | xargs -n 1 -I{} cp -p {} .config/home_dot_files

