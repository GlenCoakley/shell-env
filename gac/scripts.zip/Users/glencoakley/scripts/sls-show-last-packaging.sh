stack=$(jq -r '.service.service' .serverless/serverless-state.json)
region=$(jq -r '.service.provider.region' < .serverless/serverless-state.json | uniq)
stage=$(jq -r '.service.provider.stage' < .serverless/serverless-state.json | uniq)
if [ "$(echo $stage | wc -w)" -gt 1 ]; then
  stage=$(jq -r '.service.provider.stage.stage' < .serverless/serverless-state.json | uniq)
fi

echo "Serverless last ran for stack: $stack, stage: $stage, region: $region"

