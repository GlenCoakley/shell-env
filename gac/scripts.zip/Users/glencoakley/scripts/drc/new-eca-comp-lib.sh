#!/bin/sh

mv ~/.npmrc ~/.npmrc.bak
grep -v ^strict-ssl < ~/.npmrc.bak > ~/.npmrc

npm i @drc-eca/eca-components-lib

mv -f ~/.npmrc.bak ~/.npmrc

