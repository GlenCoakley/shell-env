#!/bin/sh
# If you manually remove either of the 'node_modules' or '.dyunamodb' subdirectories it will prevent the local
# 'serverless' command from running properly. This will fix it and possibly other causes of the error:
#    Cannot load dynamodb.

# Whatever occasionally nukes this plugin does not do it cleanly. So, uninstall all remnants.
sls plugin uninstall --stage dev --region us-east-2 --name serverless-dynamodb-local

# Install the plugin into serverless (sls).
sls plugin install --stage dev --region us-east-2 --name serverless-dynamodb-local
sls dynamodb install --stage dev --region us-east-2
