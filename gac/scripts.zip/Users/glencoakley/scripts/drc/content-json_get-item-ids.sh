jq -r 'del(.form.sessions[].helpcategorys)' | \
   jq -r '.form.sessions[].sections[].questionNumbers[].drcId' | \
   sort

