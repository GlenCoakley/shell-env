cd $wksp/lrc/form-rec-svc
#cd spec/integration/fixtures
ack -A1 'new .*FormTest\(' --type=ts spec/integration/fixtures | grep name: | \
	sed -e 's#LRC_1008_skewed_BW_sections_absent/##g' | \
	sed -e 's#.*fixtures/##g' | \
	sed -e 's#[/_.-][Ee]xpectedResults.*name:##g' | \
	tr '/' '^'

	#sed -e 's^LRC_1008_skewed_BW_sections_absent/^^g' | \
