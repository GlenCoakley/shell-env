echo "AWS MFA code is required."
aws-role
aws s3 ls us-east-1-drc-serverlessdeployments-le/serverless/

