#!/usr/bin/env sh

label=$1
case "$label" in 
  [dD][rR][cC]) npm config set registry http://artifactory.datarecognitioncorp.com/artifactory/api/npm/drc_virtualnpm/
	;;
  [dD][eE][fF]*) npm config set registry https://registry.npmjs.org
	;;
  *) echo "Unknown registry indicator: $label"
	;;
esac

