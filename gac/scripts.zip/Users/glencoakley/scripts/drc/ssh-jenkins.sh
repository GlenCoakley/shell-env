#!/usr/bin/env sh
# Linting via the CLI with SSH
# ssh (Jenkins CLI)
JENKINS_SSHD_PORT=22
JENKINS_HOSTNAME=gcoakley@jenkinsci.datarecognitioncorp.com
ssh -p $JENKINS_SSHD_PORT $JENKINS_HOSTNAME declarative-linter < Jenkinsfile


