#!/bin/sh

OUTPUT_DIR=test_integration_output/
rm -rf $OUTPUT_DIR
mkdir -p $OUTPUT_DIR

~/scripts/drc/form-runner-show-forms.sh | while read FORM_ID FORM_TEST_NAME; do
   OUTPUT_FILE_PREFIX=${OUTPUT_DIR}testing
   NAME=$(echo $FORM_TEST_NAME | tr -d "'\",")
   OUTPUT_FILE_ID=$(basename $FORM_ID)

   echo "Running tests for: $FORM_ID - $FORM_TEST_NAME"
   env FORM_RUNNER="^${NAME}$" npm run test:integration:no-nyc > ${OUTPUT_FILE_PREFIX}-${OUTPUT_FILE_ID}.out 2>&1
done

