#!/usr/bin/env sh

COLS=$(tput cols)

for f in $@; do 
    fmtd=$(echo $f | sed -e 's/.json/.fmtd.json/')
    printf "%-${COLS}s\r" "$f"
    jq '.' < $f > $fmtd
done
echo ''

