echo "month Jan-Dec, 1-12; day 0-3, 0-9; year 0-2, 0-9, 0-9, 0-9"
for d in */demographicResults.json; do echo $d; jq -cj '.[]|select(.humanReadableId | contains("DOB")) | .name + ":", .answer, ", "' $d; echo ''; done

