eval `npm audit | grep '^# Run ' | sed -e 's/.*Run \(.*\) to resolve.*/\1/'`
