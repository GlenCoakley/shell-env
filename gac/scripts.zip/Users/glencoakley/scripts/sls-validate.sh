#!/usr/bin/env bash

SLS_FILE=serverless.yml
CFG_FILE=$(dirname $0)/sls-yaml.cfg

yamllint -c $CFG_FILE $SLS_FILE

# https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/best-practices.html#validate
# Best practice: run 'sls package' then run CloudFormation template validation from here: 
#   sls package --stage dev --region us-east-1 $@
#   aws cloudformation validate-template --template-url file://.serverless/cloudformation-template-update-stack.json

sls deploy --noDeploy --stage dev --region us-east-1 $@

