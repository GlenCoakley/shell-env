#!/usr/bin/env bash

SLS_CFG_ARG=$(echo $@ | grep -c -- '-c\b\|--config\b')
if [ "$SLS_CFG_ARG" -ge 1 ]; then
	SLS_CFG_FILES=$(echo $@ | sed -e 's/-c//g' -e 's/--config//g')
else
	SLS_CFG_FILES=$(ls -1 {sls,serverless}*.{yaml,yml,json,js} 2>/dev/null)
fi

CFG_FILE=$(dirname $0)/sls-yaml.cfg
export DRC_LAYER=test # This doesn't matter

set -x
yamllint -c $CFG_FILE $SLS_CFG_FILES

for slsConfig in $SLS_CFG_FILES; do 

	# Best practice: run 'sls package' then run CloudFormation template validation.
	# https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/best-practices.html#validate
	sls package --stage dev --region us-east-1 --config $slsConfig
	
	aws cloudformation validate-template --template-body .serverless/cloudformation-template-update-stack.json

	sls deploy --noDeploy --stage dev --region us-east-1 --config $slsConfig
done

