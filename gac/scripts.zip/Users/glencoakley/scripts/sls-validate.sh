#!/usr/bin/env bash
# Performs as much validation as possible, locally, on a serverless configuration. The desire is to catch as many
# problems with changes made to Serverless configuration before having to go through the (commit it, push it, PR it,
# merge it, and) run it in Jenkins cycle.
#
# This requires active AWS authentication. Before running this be sure you have logged into AWS SSO 'aws sso login'
# and used those credentials to update your shell's environment variables.
#
SLS_CFG_ARG=$(echo $@ | grep -c -- '-c\b\|--config\b')
if [ "$SLS_CFG_ARG" -ge 1 ]; then
  SLS_CFG_FILES=$(echo $@ | sed -e 's/-c//g' -e 's/--config//g')
else
  SLS_CFG_FILES=$(ls -1 {sls,serverless}*.{yaml,yml,json,js} 2>/dev/null)
fi

CFG_FILE=$(dirname $0)/sls-yamllint.cfg
if [ ! -r "$CFG_FILE" ]; then
  CFG_FILE=~/scripts/sls-yamllint.cfg
fi

#trap "exit 1" ERR

# Note, some syntax that is specific to Cloudformation will cause yamllint to fail.
# In that case you can use yaml-cfn instead.
# Some web pages suggest using cfn-lint but, that has been deprecated and rolled into
# 'aws cloudformation validate-template'.
echo 'Use yaml-cfn (install via npm) if your serverless configuration contains Cloudformation specific code.'
echo 'Linting files:'
echo ''
yamllint -c $CFG_FILE $SLS_CFG_FILES

for slsConfig in $SLS_CFG_FILES; do

  echo ''
  # Best practice: run 'sls package' then run CloudFormation template validation.
  # https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/best-practices.html#validate
  echo "Using serverless to package: ... --config $slsConfig --stage dev --region us-east-1 --color blue"
  sls package --max-old-space-size=4096 --config $slsConfig --stage dev --region us-east-1 --color blue 
  # | grep -v '[][]\|^Entrypoint'

  if [ "$?" -eq 0 ]; then
    echo "Validating Cloudformation template of $slsConfig..."
    aws cloudformation validate-template --template-body file://.serverless/cloudformation-template-update-stack.json
  fi
	
  # I am fairly sure that `sls deploy --noDeploy` does both of those since it invokes something called
  # 'aws:common:validate' which looks like it might be the `aws validate-template` operation which operates on the
  # Cloudformation file that results from the `sls package` command.
  #
  # When using assume-role when I had no write permissions to environments this would work fine. From that I conclude
  # that it did not try to write anything to the target environment. You may have a different experience (ref: warning).
  # The documentation for the Serverless AWS plugin does not list a '--nodeploy' option but, the source code for the
  # plugin does check for it and execute different code.
  #
  # TODO compare to validate-template output for different types of errors.
  #
  # WARNING: This next command is not safe to use with serverless-drc-extras since it does not support '--noDeploy'.
  # sls deploy --max-old-space-size=4096 --noDeploy --config $slsConfig --stage dev --region us-east-1 --color blue
done
