#!/bin/sh

case "$(uname -s)" in
  *Darwin*)  # This assumes Chrome is installed in the default location.
	chromeExec='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' ;;
  *Linux*)   # This assumes google-chrome is in the PATH.
	chromeExec='google-chrome' ;;
  *Windows*) # This assumes chrome.exe is in the PATH.
	chromeExec='chrome.exe' ;;
  *) echo 'Unknown operating system. Chrome executable name unknown.'; exit 1 ;;
esac

exec "$chromeExec" $@
