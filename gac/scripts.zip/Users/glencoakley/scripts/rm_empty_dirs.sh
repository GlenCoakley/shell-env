#!/bin/sh

DEF_DIR=${1:-.}
shift
find $DEF_DIR $@ -type d -empty | xargs rmdir

