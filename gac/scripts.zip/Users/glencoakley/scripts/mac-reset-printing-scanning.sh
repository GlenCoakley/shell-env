# Remove exiting printers and scanners.

lpstat -p | cut -d' ' -f2 | xargs -I{} lpadmin -x {}


# Manually reset the printing system on MacOSX.
# ref: https://www.cnet.com/news/what-does-the-reset-print-system-routine-in-os-x-do/

# Stop CUPS
sudo launchctl stop org.cups.cupsd

# Remove CUPS config file
sudo rm /etc/cups/cupsd.conf

# Restore the default config by copying it
sudo cp /etc/cups/cupsd.conf.default /etc/cups/cupsd.conf

# Remove the printers
sudo rm /etc/cups/printers.conf

# Start CUPS again
sudo launchctl start org.cups.cupsd

# Ensure propery file ownership.
sudo chown -R root:wheel /Library/Printers
sudo chown -R root:wheel /usr/libexec/cups

# Ensure propery file permissions.
sudo chmod -R 755 /Library/Printers
sudo chmod -R 755 /usr/libexec/cups

# Run 'printtool' manually
# /System/Library/Frameworks/ApplicationServices.framework/Versions/A/Frameworks/PrintCore.framework/Versions/A/printtool daemon

