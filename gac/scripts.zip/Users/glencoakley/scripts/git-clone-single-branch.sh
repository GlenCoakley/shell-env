git clone \
  --filter=blob:none \
  --no-checkout \
  --single-branch \
  --branch master \
  $@

