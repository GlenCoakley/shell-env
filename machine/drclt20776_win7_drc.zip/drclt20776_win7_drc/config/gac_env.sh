#
# Some example alias instructions
# If these are enabled they will be used instead of any instructions
# they may mask.  For example, alias rm='rm -i' will mask the rm
# application.  To override the alias instruction use a \ before, ie
# \rm will call the real rm not the alias.
#
alias cde=cd
alias cp='cp -p'

# Interactive operation...
# alias rm='rm -i'
# alias cp='cp -i'
alias mv='mv -i'

# Default to human readable figures
alias df='df -h'
alias du='du -ch'

# Misc :)
alias 7z='/c/Progra~1/7-Zip/7z'
alias choc-installed="choco list --local-only | sort" # or: cinst -l | sort
alias choc-upgrade='choco upgrade chocolatey'
# curlg ~= 'curl --insecure --location --include --silent --show-error'
alias curlg='curl --kLisS'
alias ct='clear; date;'
alias diff='diff -b'
alias dird=lsd
alias ec='vi /c/dev/config/gac_env.sh ; echo /c/dev/config/gac_env.sh'
alias ee=ec
alias findf='find . -type f'
alias findd='find . -type d'
alias grep='grep --color'                     # show differences in colour
alias egrep='egrep --color=auto'              # show differences in colour
alias fgrep='fgrep --color=auto'              # show differences in colour
alias hg='history | grep'
alias k=exit
alias less='less -eF'
alias lsd='find . -maxdepth 1 -type d'
function mcd() { mkdir -p $@; cd $@; }
# Don't set the LESS environment variable as it causes git output to mishandle the terminal. 
alias more=less
alias m=more
alias mroe=more
function npp() { /c/dev/bin/Notepad++/notepad++.exe $@ & }
alias rfp='reset-windows-file-perms'
alias scp='scp -i ~/.ssh/drc_id_rsa'
alias sftp='sftp -i ~/.ssh/drc_id_rsa'
alias shell-options='set -o'
alias show-shell-options='set -o'
alias ssh='ssh -i ~/.ssh/drc_id_rsa'
alias tty-reset='reset'
function which() { type -a $1 | sed -e "s/^$1 is //g"; }    # where, of a sort
alias wihch=which
alias whence='type -a'                        # where, of a sort

#
# Some shortcuts for different directory listings
# source ~/scripts/ls-colors.sh
alias lrt='ls -lrt'
alias lt='ls -lt'
alias ls='ls -Ch --file-type --color=no'                 # classify files in colour
alias dir='ls --color=no --format=vertical'
# alias vdir='ls --color=no --format=long'
alias la='ls -A'                    # all but . and ..
alias ll='ls -l'                    # long list
alias lla='ls -lA'                  # long list of all but . and ..
alias lld='ls -lad'                 # long list as directories--don't show directory contents.

# PATH=$(~/scripts/path-remove '/windows/System32' 'SQL Server/')
export PATH=~/scripts/drc:~/scripts:~/bin:./node_modules/.bin:/c/dev/bin/grails-2.4.5/bin:/c/dev/bin/mongo-3.2.11/bin:/c/dev/bin/dockerToolbox:${PATH}

PATH="${PATH}:/c/home/gcoakley/perl5/bin"; export PATH;
PERL5LIB="/c/home/gcoakley/perl5/lib/perl5${PERL5LIB:+:${PERL5LIB}}"; export PERL5LIB;
PERL_LOCAL_LIB_ROOT="/c/home/gcoakley/perl5${PERL_LOCAL_LIB_ROOT:+:${PERL_LOCAL_LIB_ROOT}}"; export PERL_LOCAL_LIB_ROOT;
PERL_MB_OPT="--install_base \"/c/home/gcoakley/perl5\""; export PERL_MB_OPT;
PERL_MM_OPT="INSTALL_BASE=/c/home/gcoakley/perl5"; export PERL_MM_OPT;

function winmerge() { /c/Progra~2/tools/WinMerge/WinMergeU.exe $@ & }


# General development
#
function goto_pkg_json() { 
  [ ! -r package.json ] && [ -r app/package.json ] && cd app; 
  [ ! -r package.json ] && [ $(basename $PWD) = "app" ] && cd ..; 
}

source ${GAC_CFG_DIR}/git-completion.bash
# source ${GAC_CFG_DIR}/dflt_completion_handler_for_npx.bash
source ${GAC_CFG_DIR}/my-git-prompt.bash
# my-git-prompt replaces: source ${GAC_CFG_DIR}/bash-git-prompt.bash
source ${GAC_CFG_DIR}/ssh-agent-start.sh

alias git='/cygdrive/c/Progra~1/Git/bin/git.exe'
alias gb='git branch'
alias gba='git branch --all'
alias gcd='git checkout develop'
alias gch='git checkout'
alias gcl='git clone'
alias gco='git commit'
alias gd='git diff'
alias gs='git status'
alias gp='git pull'

alias grails='grails --stacktrace'
alias grails245='/c/dev/bin/grails-2.4.5/bin/grails --stacktrace'
alias grails256='/c/dev/bin/grails-2.5.6/bin/grails --stacktrace'

# https://docs.npmjs.com/misc/config
alias ni='goto_pkg_json; [ -r package.json ] && npmo install'
alias nitbi='goto_pkg_json; [ -r package.json ] && npmo install && npmo install-test && bower install'
#alias npitubpiu='npm prune && npmo install && npmo install-test &&^ npm update && bower prune && bower install && bower update'
function npml() { npmo --registry http://127.0.0.1:2222 $@; }
alias npui='npm prune && npm install && npm update'
# https://docs.npmjs.com/misc/config
alias ni='goto_pkg_json; [ -r package.json ] && npmo install'
# npm's "--cache-min Infinity" has been deprecated for "--prefer-offline".
alias nrd='npmo run dev'
alias nubu='goto_pkg_json; [ -r package.json ] && npm update && bower update'

alias nb='npm run build'
alias ns='npm run start'
alias nt='npm run test'
alias nti='npm run test:integration'
alias ntu='npm run test:unit'
alias nss='npm-show-scripts'

function win() { PATH=/c/windows/system32:$PATH $@ ; }

export VAGRANT_HOME=c:/dev/runtime/vagrant


# DRC development
#
# Setting BROWSER stops Karma from complaining:
#    browser_gpu_channel_host_factory.cc(121)] Failed to launch GPU process.
export BROWSER=google-chrome
export GHDRC=https://github.com/DataRecognitionCorporation/
export NPM_GCACHE="/c/dev/runtime/npm_global"
export WKSP=/c/dev/wksp
export ECA=$WKSP/eca

function cdToIfExists() { 
  if [ -n "$1" ]; then
    if [ -d $1 ]; then cd $1; return 0; 
    else 
      expandsTo=$(/bin/ls -1d *$1*)
      count=$(echo "$expandsTo" | wc -l)
      if [ $count -gt 1 ]; then echo "Found matches:" $expandsTo;
      elif [ -d *$1* ]; then cd *$1*; return 0;
      fi
    fi
  fi
  return 1;
}
alias npmgls='ls $NPM_GCACHE/node_modules/'
function wksp() { cd $WKSP; cdToIfExists $1 && goto_pkg_json; }
alias ws='wksp'
function eca() { cd $ECA; cdToIfExists $1 && goto_pkg_json; }
function ts() { cd $ECA/typescript; cdToIfExists $1 && goto_pkg_json; }

alias diff="\diff -x package-lock.json -x node_modules"
alias ei='cd $eca/typescript/eca-ideas-portal-ui'
alias it='iat-test'
alias codenarc='grails --offline codenarc'
alias grailssh='grails --offline shell'
alias groovysh='/c/dev/bin/groovy-sdk-2.3.3/bin/groovysh'
alias nc='/c/dev/runtime/npm_caching/npm_lazy/start-auto-caching.sh &'
alias ngs='ng serve -v --port 4321'
function npri() { npm uni $@; npm cache clean; npm i $@; }
function yari() { yarn remove $@; yarn cache clean $@; yarn add $@; }
alias yarn='yarn --prefer-offline'


#THIS MUST BE AT THE END OF THE FILE FOR SDKMAN TO WORK!!!
#export SDKMAN_DIR="/c/home/gcoakley/.sdkman"
#[[ -s "$SDKMAN_DIR/bin/sdkman-init.sh" ]] && source "$SDKMAN_DIR/bin/sdkman-init.sh"
#alias sdkman=sdk


# export OPENCV4NODEJS_DISABLE_AUTOBUILD=1
# export OPENCV_ROOT='c:/dev/wksp/3rd_party/opencv/opencv-3.3.1/build'
# export OPENCV_INCLUDE_DIR=${OPENCV_ROOT}'/include'
# export OPENCV_LIB_DIR=${OPENCV_ROOT}'/x64/vc14/lib'
# export TESSERACT_ROOT=/c/dev/bin/tesseract
# export PATH=$PATH:${OPENCV_ROOT}'/x64/vc14/bin':$TESSERACT_ROOT
# export TESSDATA_PREFIX=$TESSERACT_ROOT/tessdata
function ass() { 
  envAbbr=$1
  unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SECURITY_TOKEN AWS_SESSION_TOKEN
  file=$TMP/ar.out
  trap "rm -f $file" 0 1 2 3
  assume-role -duration 43200s drc$envAbbr | sed -e 's/^\$env:/export /g'  > $file
  source $file
  env | grep ^AWS # To allow visual confirmation that it worked.
}
alias ardev='ass dev'
alias arprod='ass prod'

alias wiat="cd $WKSP/grails/iat/iatapp"
alias wiats="cd $WKSP/grails/iat-spare/iatapp"

alias wrtml="ts eca-rtm-service/lib/eca-rtm-model"
alias wrtms="ts eca-rtm-service"
alias wrtmu="ts eca-rtm-ui"

alias wra="ts rtm-app"
alias wrl="ts rtm-app/service/lib/eca-rtm-model"
alias wrs="ts rtm-app/service"
alias wru="ts rtm-app/ui"

# For Local Resource Capture (LRC) / Local Scanning
export SKIP_PAYLOAD_LOG=true
alias wla="ts lrc/lrc-api"
alias wlu="ts lrc/lrc-ui"
alias wlf="ts lrc/form-rec-svc"
alias wlfr="ts lrc/form-rec-svc"
alias wlfu="ts lrc/form-rec-util"
alias wludb="ts lrc/lrc-udb-service"

