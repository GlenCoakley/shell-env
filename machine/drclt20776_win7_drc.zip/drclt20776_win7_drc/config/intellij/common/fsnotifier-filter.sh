"C:\Program Files\JetBrains\IntelliJ IDEA 2017.3.2\bin\fsnotifier64.exe" | \
	grep -vi 'c:\users\gcoakley'