grails.work.dir = "c:/dev/runtime/grails/2.4.5/work_dir"
grails.dependency.cache.dir = "c:/dev/runtime/maven_repo"
