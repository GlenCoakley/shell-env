grails.work.dir = "c:/dev/runtime/grails/2.5.6/project_plugin_cache"
grails.dependency.cache.dir = "c:/dev/runtime/grails/2.5.6/dependency_cache"
